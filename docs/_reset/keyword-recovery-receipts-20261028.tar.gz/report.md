# Genuine fresh-cluster keyword identifier recovery

Fixture-only worktree: `/workspace/.cryptalis-cloud/frame-keyword-recovery`, based on `b48b360`. The integrated, optimized `_sqlalchemy_search.py` was copied from root as the product baseline for source qualification only. That copied product file is excluded from the handoff patch. No main checkout edits, commits or dependency/environment mutations.

Handoff patch: `/tmp/cryptalis-keyword-recovery-fixtures.patch`, SHA-256 `6166dca4a477f98d87a133a7133e34bad6dc8671dd25f1ed85bb1fce164cbc75`.

Four owned fixture/harness files:

- `tests/test_migration.py`: optional `value_column='name'` preserves the existing default, keeps the Python attribute `name`, uses the physical column as the Table key and maps that attribute explicitly. `frames()` reads the compiled physical column and quotes it through the native preparer.
- `scripts/fresh_cluster_qualification.py`: bounded `--column-name integer` requires the existing `--integer` profile, carries the selected name into both phases, and independently validates integer profile, width, physical column, successor kind and lock schema before the layout-specific checks. Thus `--public-slots` cannot skip integer identity admission.
- `tests/test_fresh_boolean_export.py`: uses the selected physical column and records it in the retained manifest.
- `tests/test_fresh_boolean_restore.py`: checks manifest/environment/lock agreement; uses native identifier quoting for restore reads, tamper/repair, the ORM mapping and package-free child; records frame restatements. A keyword run must actually produce its expected frame restatement during adoption.

Final evidence uses the same fixture revision `worktree-fba8254f8e178863` and stable source/runtime bindings in every export/restore wrapper. All primary and fresh-cluster role probes pass. Each fresh target is initialized with `initdb`, receives new role credentials, is restored from real `pg_dump` output, and stops successfully at harness completion. Source fixture schemas are dropped after export. The source cluster itself remains running; this is not production writer-fencing qualification.

Executed final runs:

| Run directory | Physical column/layout | Runtime | Result |
| --- | --- | --- | --- |
| `/tmp/cryptalis-keyword-integer-installed-legacy-20261028` | `integer`, column replacement | Installed final wheel | Export 1 passed; fresh restore journey 1 passed |
| `/tmp/cryptalis-keyword-integer-installed-slots-20261028` | `integer`, preserved public slots | Installed final wheel | Export 1 passed; fresh restore journey 1 passed |
| `/tmp/cryptalis-keyword-integer-source-name-control-20261028` | Default `name`, column replacement | Explicit worktree source | Export 1 passed; fresh restore journey 1 passed |

No failures or skips occur in these six final test calls. `git diff --check` passes. An initial source keyword/column-replacement journey also passed before the final harness guard/restatement assertion was added; its separate earlier receipts remain at `/tmp/cryptalis-keyword-integer-legacy-20261028` and are not the final fixture evidence.

The installed runs use `/workspace/.cryptalis-cloud/wheel-frame-venv/bin/python`, empty `PYTHONPATH` and explicit `--installed-wheel /workspace/.cryptalis-cloud/frame-identifier-final-artifacts/cryptalis-0.1.0-py3-none-any.whl`. Both wrapper phases bind to wheel SHA-256 `b560cb8aa830448a7f3d56fecd0c51f71e5e3a6d684d660bd301c98cdc9db7af`. The retained wheel environment is unchanged. The source backward control uses the core interpreter with explicit worktree `src`/`tests` paths; the wrapper identifies the actual imported runtime as that worktree.

For each installed layout, the existing integer path proves native plaintext backup recovery, payload rotation before protected backup, actual fresh-cluster restore, refusal of ordinary stale deployment admission, corrupt-frame refusal before adoption, exact keyword CHECK restatement admission, typed attached reads, a latest protected edit, explicit current-data decrypt-back/removal, and a new process denying all Cryptalis imports that reads the latest native int4 values and checks the native column type. The public-slot run also compares restored final column slots with the retained source slot inventory.

Exact fixture hashes, public artifact hashes, wrapper runtime/preflight/stability facts and journey records are combined in `/tmp/cryptalis-keyword-recovery-evidence-20261028.json`. Each directory retains `export-receipt.json`, `restore-receipt.json`, `restore-manifest.json`, and `integer-32-journey-receipt.json`. Archive only intended evidence files; the work directories also contain private generated database credential files that must stay outside Git.

Installed reproduction after loading the authorized source-cluster environment:

```sh
PYTHONPATH= /workspace/.cryptalis-cloud/wheel-frame-venv/bin/python scripts/fresh_cluster_qualification.py --workdir NEW_PRIVATE_DIRECTORY --integer 32 --column-name integer --installed-wheel /workspace/.cryptalis-cloud/frame-identifier-final-artifacts/cryptalis-0.1.0-py3-none-any.whl
```

Add `--public-slots` for the second layout. Use a new work directory. All pytest execution remains under the existing mandatory wrapper; managed-environment socket permission is required for the local PostgreSQL probes and fresh cluster. No live key provider or external authority is involved.

This closes the bounded local installed keyword/int4 fresh-recovery evidence gap for both layouts. It does not qualify keyword text fresh recovery, all keyword names, production deployment, external custody/deletion, independent review or any full production gate. All seven full gates remain UNKNOWN. Root owns canonical documentation, evidence archival, integration and publication.
