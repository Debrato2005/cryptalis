# PostgreSQL identifier deparser correction

Worktree: `/workspace/cryptalis-frame-quoting`, detached at verified `d328b36b36b8b3e2a5e800bf384ab938e9baa4e3`. No shared-checkout edits or commits. The Count agent's failed `/tmp/cryptalis-count-frame-diagnosis.json` is untouched.

Reproduction confirms a real compatibility bug. A native int4 column named `integer` receives a valid, validated CF1 CHECK with the exact declared dependency and width/header/generation checks. PostgreSQL deparses every identifier occurrence as `"integer"`; SQLAlchemy's normal quote method produces `integer`. `_frame_expressions()` used only the latter spelling, so activation returned `active_schema_mismatch`. `pg_catalog.quote_ident('integer')` agrees with the actual deparser. Read-only PG16 keyword inspection found 64 spelling differences among 471 server keywords, so this was not limited to one column name.

Evidence:

- `/tmp/cryptalis-frame-identifier-diagnosis-20261028.json`: one diagnostic passes by reproducing the typed failure; this is not successful activation evidence.
- `/tmp/cryptalis-frame-identifier-facts.json`: public synthetic expected/actual CHECK expressions, dependency and keyword category.
- `/tmp/cryptalis-frame-quote-keywords-20261028.json` and `/tmp/cryptalis-frame-quote-keywords.json`: read-only keyword inventory and exact differences.
- `/tmp/cryptalis-frame-identifiers-red-final-20261028.json`: meaningful RED, 8 `active_schema_mismatch` failures and 6 successful ordinary/mixed-case/embedded-quote lifecycle controls.
- `/tmp/cryptalis-frame-identifiers-green-first-20261028.json`: all initial 14 focused cases pass after the correction.
- `/tmp/cryptalis-frame-identifiers-affected-20261028.json`: 173 passed, 2 skipped in 69.97 pytest seconds. Modules: 14 identifier, 73 integer, 75 search, 9 public-slot, 2 restore passes. The two integer skips require an explicitly supplied retained pre-integer reader interpreter, which was unavailable. No failed probes/tests or collection skips in this run.
- `/tmp/cryptalis-frame-identifiers-final-20261028.json`: final 16 focused cases pass in 12.11 pytest seconds after adding two native CHECK reparse/restatement admission cases. No skips or failures. Source/runtime bindings stable.
- `git diff --check`: pass.

All pytest runs use the worktree's mandatory `scripts/test_postgres.py`, the existing core interpreter, explicit `PYTHONPATH=/workspace/cryptalis-frame-quoting/src:/workspace/cryptalis-frame-quoting/tests`, and the authorized socket/network permission. The wrapper probes all three declared roles. It records the actual runtime root as this worktree, not the shared editable checkout. Final product module digest: `4c56b949e1230ed198c4989ece9a3f1b393b959112483242e6e6e82bb2ca5711`, over 43 modules.

Bounded changes:

- `src/cryptalis/_sqlalchemy_search.py`: known frame forms preserve the original first two nested/flattened results, then add only the same identifier rendered by the supplied native PostgreSQL preparer's `quote_identifier()`. The live CHECK must have exactly one dependency, the declared column. Default admission still permits nested forms only. Flattened forms still require the exact explicitly admitted restatement, and the live expression must equal it. No quote stripping, SQL parsing, bound/header relaxation or format/grammar/crypto change.
- The search index validator uses a bound `pg_catalog.quote_ident(%s)` result for the expected deparser column spelling. This adds one read-only catalog query per searchable-field validation; no performance qualification is claimed.
- `tests/test_frame_identifier_storage.py`: both layouts exercise native integer storage and keyword-text equality/IN, edits, current-value reversal/removal, ordinary/mixed-case/embedded-quote identifiers, changed bounds and extra dependencies before key preparation. Two additional native deparse/reparse cases establish that flattened checks still require the exact admitted expression and that weakened bounds cannot be admitted as a restatement.
- `tests/test_fresh_cluster_restore.py`: only the existing private-helper unpack gains `*_` to retain its original canonical/flattened assertions with additional known spelling forms.

Initial RED fixture attempts are retained, not overwritten: `/tmp/cryptalis-frame-identifiers-red-20261028.json`, `/tmp/cryptalis-frame-identifiers-red-corrected-20261028.json`, `/tmp/cryptalis-frame-identifiers-red-native-20261028.json`, and `/tmp/cryptalis-frame-identifier-control-failure-20261028.json`. They exposed test-fixture issues before product edits: undeclared native uniqueness, SQLAlchemy native keyword quoting, physical-column-key/ORM-property mapping, and use of a previously attached mapped type for the native exit assertion. The corrected RED isolates the real activation bug; ordinary controls pass end to end.

Reviewable patch: `/tmp/cryptalis-frame-identifiers.patch`. It contains only the three owned files, including the new test. Root owns integration, canonical documentation, archived evidence and commits.

This is bounded local PostgreSQL16 source evidence. The native deparse/reparse controls do not substitute for a new genuine fresh-cluster restore, installed-wheel run, production cell or independent review. No such claims or gate promotion follow. All seven production gates remain UNKNOWN.
