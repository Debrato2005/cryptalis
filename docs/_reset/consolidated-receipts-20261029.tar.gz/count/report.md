# Terminal Table reporting hardening handoff

Source base: `f3de39b`, detached isolated worktree
`/workspace/.cryptalis-cloud/count-terminal-table-20261029`.

Owned patch consists of exactly two files. No commit, canonical document,
dependency, manifest, frame or format was changed. The old plural-engine Count
WIP remains untouched.

- `src/cryptalis/_sqlalchemy_aggregate.py`: import native `Table`, then use existing
  `_delete_node(source, Table)` after the recursive Alias walk and before checking
  the terminal physical table against the owned binding. This validates the
  renderer of the final table as well as each alias.
- `tests/test_count_terminal_table.py`: real PostgreSQL native/protected controls
  for a changed terminal table compiler and admitted alias/statistical queries.

## Failure and correction

A changed native owned Table compiler can produce a derived relation that
relabels rows from both physical tenants with one public tenant UUID. Native
plaintext COUNT DISTINCT still deduplicates equal text from both tenants.
Protected COUNT DISTINCT uses tenant-bound terms, so the one-tenant proof is
invalid when the renderer changes those tenant labels. Native Table identity
alone did not establish native Table dispatch.

The regression seeds two tenants sharing one text value plus one other-only
value and NULL. The counterfeit native query yields exactly two logical values.
The protected counterfeits must refuse before statement keys or driver SQL.
Both one-level and nested native Alias chains exercise the terminal Table.

The fix reuses the exact native compiler admission already used for aliases,
columns and count structures. It adds no host-tenant filter or provider request.
COUNT remains unauthenticated public statistics under the current main contract.

## Actual evidence

All PostgreSQL executions used the mandatory wrapper, sourced the authorized
cloud environment, explicitly bound PYTHONPATH to this isolated source tree,
and obtained fresh successful probes for both existing roles. No substitute
database or retry of a failed probe occurred.

- `/tmp/cryptalis-count-terminal-table-red-20261029.json`: 1 passed, 3 failed,
  exit 1, source unchanged. Named-alias counterfeit did not refuse. Nested
  counterfeit refused only after statement keys. The third failure exposed
  an existing manually nested Alias DISTINCT limitation, described below.
- `/tmp/cryptalis-count-terminal-table-green-candidate-20261029.json`: 3 passed,
  1 failed, exit 1, source unchanged. Both counterfeit cases now refused before
  keys/SQL. Only the same pre-existing nested DISTINCT limitation remained.
- `/tmp/cryptalis-count-terminal-table-green-20261029.json`: 56 passed, exit 0,
  source unchanged. Includes focused new controls plus existing
  `test_sqlalchemy_counts.py`, `test_sqlalchemy_distinct.py`,
  `test_sqlalchemy_identity_distinct.py`, and
  `test_sqlalchemy_public_distinct.py`.

Final positive controls preserve direct models, ordinary aliases, nested ORM
aliases and explicit named aliases for non-NULL counts, scoped COUNT DISTINCT
and separate public tenant groups. A session for tenant A can still count tenant
B's public statistics. A genuinely nested Table Alias chain retains native
non-NULL COUNT. Existing sync/async COUNT, FILTER/windows, direct representative
DISTINCT, identity DISTINCT and public DISTINCT checks all pass in the 56-check
selection. `git diff --check` passed. No installed-wheel or full-corpus run was
claimed for this tiny isolated patch; root integrates and qualifies separately.

## Existing separate limitation

An explicitly constructed `table.alias('inner').alias('outer')` COUNT DISTINCT
with a tenant equality passes initial main shape admission but refuses later.
`rewrite_search` preserves the Count object's argument alias while cloning the
WHERE alias. `_one_tenant` then compares those aliases by object identity.
An offline exact-source reproduction gave initial shape True and rewritten
shape False, and the initial real PostgreSQL RED showed the same failure before
any product edit. The guard does not cause it. The final positive matrix uses
the admitted alias forms; the true nested chain is covered for non-distinct
COUNT and for counterfeit refusal. This handoff makes no new nested DISTINCT
admission claim and does not weaken alias identity to mask the limitation.

All seven production gates remain UNKNOWN. This patch is finite AST dispatch
hardening, not independent security review or production qualification.
