# Tenant maintenance CLI handoff — 2026-10-28

IMPLEMENTED and VERIFIED only on the approved development PostgreSQL 16 target with public key fixtures. All seven production gates remain UNKNOWN.

Candidate: `/workspace/.cryptalis-cloud/tenant-provision-cli`, branch `wip/tenant-provision-cli-20261028`, base `0d96bbab3c62b8c1a861cfa04ce81dca579556a7` (fast-forwarded from approved b48b360). Parent main's later e8705ee fixture changes are not present here. No commits, main/shared-doc edits, package/environment changes, or other product changes made by this slice.

## Bounded implementation

`cryptalis tenants provision plan|apply|activate|abort` composes the existing maintenance policy API. Planning receives the exact typed UUID and trusted Keyring only from a `MODULE:FACTORY` returning `TenantPlanningContext`; no tenant/key-authority command flag exists. Apply/activate use exact `TenantApplyContext`/`TenantActivationContext` with host-pinned existing+new keys. Cancel uses `TenantAbortContext` with source-only keys and source ACTIVE pin. Every context supplies a fresh owned synchronous psycopg Engine, disposed on all command outcomes after it is returned.

The existing rewrap lifecycle runner was generalized into `_run_policy_transition`; rewrap artifacts, output scopes and behavior remain unchanged. Tenant apply durably retains the exact private successor before calling host code or attempting database effects. Existing artifact paths refuse without an exact operation UUID `--resume`; resume revalidates and re-syncs exact private regular-file bytes. Activation reads the saved v15/v16 successor and requires the actual independent host ACTIVATING pin; it does not invent publication authority. Source-only cancel reuses the Python API's inspected retry semantics. Safe typed diagnostics retain artifact facts and known progress without host exception text. Existing `status` and `doctor` accept v15 through their existing generic MigrationPlan path; Doctor still reports unobserved health UNKNOWN.

No new service, parser, crypto scheme, resolver authority, manifest version, plaintext fallback, or database-selected keys. Existing O(N) frame verification and global writer pause remain. Host factory code executes as trusted code; its external side effects and actual operational writer draining remain host responsibilities. Local durable artifact retention does not prove remote backup custody or external publication.

## Verification

Meaningful RED: `/tmp/cryptalis-tenant-cli-red-20261028.json`; existing command rejected the requested tenant workflow with InvalidArguments (one expected failed test).

Initial green: `/tmp/cryptalis-tenant-cli-green1-20261028.json`, 15 passed / 1 skipped. A later wrapper invocation used a nonexistent test filename and ran no tests; preserved `/tmp/cryptalis-tenant-cli-final-20261028.json`. It was corrected with a new receipt, never overwritten.

Final stable wrapper: `/tmp/cryptalis-tenant-cli-final2-20261028.json`: 96 passed, 3 skipped, zero failed calls, exit 0; 99 selected items. All three private roles were freshly probed. Source hashes and imported runtime binding remained unchanged. Tests: new tenant CLI, existing rewrap/ordinary/payload/search operational CLI, status and Doctor. The three skipped cases are existing opt-in genuine adopted rewrap/payload/search CLI profiles; no new tenant CLI test skipped.

The new real PostgreSQL journeys prove: read-only exact proposal planning; private proposal/successor artifacts; successor exists before host factory; PENDING; default overwrite refusal before host; explicit inspected resume; PREPARED activation pin refusal before key lookup; real ACTIVATING->ACTIVE; byte/schema identity of old rows; first approved tenant protected insert/read/equality; v15 status/Doctor observations; untyped host UUID refusal before keys/connections with engine disposal; host factory failure after durable successor with effects NONE and no invented known DB result; retained artifact retry; source-only pending cancel and terminal repeat; balanced fresh Engine disposal.

This patch directly exercises normal v15 CLI operation, not an additional genuine fresh-cluster CLI v16 restoration. The existing maintenance Python/HTTP fresh restoration receipts remain prior independent evidence. Installed-wheel CLI proof is parent-owned and pending this handoff.

## Exact owned files and hashes

- `src/cryptalis/cli.py`: `22e3a59c6a5c094693cff68bccdc07a373405fe756e9641e7b8d5254966e0a7f`
- `src/cryptalis/cli_host.py`: `baf7798d31d4657b3943c9e245fd1cbae37754e13883d8a91d7bd054082b5158`
- `src/cryptalis/_cli_operations.py`: `94780698d84e78ff788902a556df9c1c4466d15073cf9118ae4a2c4efefa4bb3`
- `tests/test_tenant_provision_cli.py`: `9b71bbca8a1b2477b464fc8d1e31fe44a1fc573d5432abe4674676e535c62d84`

`git diff --check` passes. Source diff: _cli_operations.py +51/-25; cli.py +24; cli_host.py +36. New test file: 147 lines, two behavioral journeys. Independent scoped review pending its final response.
