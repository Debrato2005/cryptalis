"""Diagnostic-only read profiling; does not change the query or result."""
import cProfile
import hashlib
import json
from pathlib import Path
import pstats

PROFILES = {}
COUNTS = {}

def pytest_collection_modifyitems(items):
    for item in items:
        module = item.module
        if module.__name__ != 'profile_current_application' or getattr(module.read, '_profiled', False):
            continue
        original = module.read
        def read(session, statement, parameters, workload, _original=original):
            label = ('attached' if hasattr(session, '_owner') else 'native') + '/' + workload
            profiler = PROFILES.setdefault(label, cProfile.Profile())
            COUNTS[label] = COUNTS.get(label, 0) + 1
            profiler.enable()
            try:
                return _original(session, statement, parameters, workload)
            finally:
                profiler.disable()
        read._profiled = True
        module.read = read

def pytest_sessionfinish(session, exitstatus):
    result = {'scope': 'diagnostic read-only cProfile; profiled latency is not qualification',
              'plugin_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'exit_status': exitstatus, 'paths': {}}
    for label, profiler in PROFILES.items():
        stats = pstats.Stats(profiler)
        rows = []
        for (filename, line, function), (primitive, calls, exclusive, cumulative, callers) in stats.stats.items():
            rows.append(dict(file=filename, line=line, function=function, calls=calls,
                exclusive_seconds=exclusive, cumulative_seconds=cumulative))
        result['paths'][label] = {'reads': COUNTS[label], 'exclusive_total': stats.total_tt,
                                 'functions': rows}
    output = Path('/workspace/cryptalis/work/application-query-cost.json')
    with output.open('x') as stream: json.dump(result, stream, indent=2)
