"""Native PostgreSQL control for schema-scoped pg_indexes deparser races."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import time
from uuid import uuid4

import psycopg
from psycopg import sql


def test_native_catalog_deparser_can_visit_a_dropping_unrelated_table():
    report = {}
    target, unrelated = ('varchar_catalog_' + uuid4().hex for _ in range(2))
    control = psycopg.connect(os.environ['CRYPTALIS_TEST_DATABASE_URL'], autocommit=True)
    blocker = psycopg.connect(os.environ['CRYPTALIS_TEST_DATABASE_URL'])
    reader = psycopg.connect(os.environ['CRYPTALIS_TEST_DATABASE_URL'], autocommit=True)
    pool, future = ThreadPoolExecutor(max_workers=1), None
    try:
        for schema in (target, unrelated):
            control.execute(sql.SQL('CREATE SCHEMA {}').format(sql.Identifier(schema)))
            control.execute(sql.SQL('CREATE TABLE {}.customer (id bigint PRIMARY KEY, name text)').format(sql.Identifier(schema)))
        old_query = ("SELECT count(*) FROM pg_catalog.pg_indexes WHERE schemaname=%s "
                     "AND tablename='customer' AND indexdef LIKE '%%substring%%'")
        plan = reader.execute('EXPLAIN (VERBOSE, COSTS OFF) ' + old_query, (target,)).fetchall()
        report['plan_sha256'] = hashlib.sha256(repr(plan).encode()).hexdigest()
        report['plan_has_deparser'] = any('pg_get_indexdef' in row[0] for row in plan)
        blocker.execute(sql.SQL('LOCK TABLE {}.customer IN ACCESS EXCLUSIVE MODE').format(sql.Identifier(unrelated)))
        oid = control.execute('SELECT %s::pg_catalog.regclass::pg_catalog.oid', (f'"{unrelated}".customer',)).fetchone()[0]
        reader.execute("SET statement_timeout = '10s'")
        def read():
            try:
                return {'count': reader.execute(old_query, (target,)).fetchone()[0]}
            except psycopg.Error as error:
                return {'sqlstate': error.sqlstate, 'class': type(error).__name__}
        future = pool.submit(read)
        deadline = time.monotonic() + 4
        waiting = False
        while time.monotonic() < deadline and not future.done():
            waiting = control.execute(
                "SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_locks WHERE pid=%s AND relation=%s "
                "AND mode='AccessShareLock' AND NOT granted)", (reader.info.backend_pid, oid)).fetchone()[0]
            if waiting:
                break
            time.sleep(0.01)
        report['old_query_waits_on_unrelated_table'] = waiting
        control.execute("SET statement_timeout = '1s'")
        report['bounded_query_count_while_unrelated_locked'] = control.execute(
            'SELECT count(*) FROM pg_catalog.pg_index WHERE indrelid=%s::pg_catalog.regclass AND indexprs IS NOT NULL',
            (f'"{target}".customer',)).fetchone()[0]
        blocker.execute(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(unrelated)))
        blocker.commit()
        report['old_query_after_unrelated_drop'] = future.result(timeout=12)
        Path(__file__).with_name('report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        assert waiting, 'Default native plan did not expose the unrelated-table dependency'
        assert report['bounded_query_count_while_unrelated_locked'] == 0
        assert report['old_query_after_unrelated_drop'].get('sqlstate') == 'XX000'
    finally:
        blocker.close()
        pool.shutdown(wait=True)
        reader.close()
        for schema in (target, unrelated):
            control.execute(sql.SQL('DROP SCHEMA IF EXISTS {} CASCADE').format(sql.Identifier(schema)))
        control.close()
