import os
import psycopg
from sqlalchemy import create_engine

def test_database_error_diagnostic():
    engine = create_engine('postgresql+psycopg://', hide_parameters=True,
        creator=lambda: psycopg.connect(os.environ['CRYPTALIS_TEST_DATABASE_URL']))
    try:
        with engine.begin() as connection:
            connection.exec_driver_sql("DO $$ BEGIN RAISE EXCEPTION 'PUBLIC_DIAGNOSTIC_EXPOSURE_CONTROL_20261101'; END $$")
    finally:
        engine.dispose()
