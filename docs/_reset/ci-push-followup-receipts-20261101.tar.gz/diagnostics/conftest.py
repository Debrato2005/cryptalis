import importlib.util
spec = importlib.util.spec_from_file_location('cryptalis_report_control', '/workspace/cryptalis/tests/conftest.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pytest_sessionstart = module.pytest_sessionstart
pytest_runtest_makereport = module.pytest_runtest_makereport
