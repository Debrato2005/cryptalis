[Skip to main content](https://openbao.org/docs/api/auth/approle/#__docusaurus_skipToContent_fallback)

Version: Version 2.7.x

On this page

This is the API documentation for the OpenBao AppRole auth method. For
general information about the usage and operation of the AppRole method, please
see the [OpenBao AppRole method documentation](https://openbao.org/docs/auth/approle/).

This documentation assumes the AppRole method is mounted at the `/auth/approle`
path in OpenBao. Since it is possible to enable auth methods at any location,
please update your API calls accordingly.

## List roles [​](https://openbao.org/docs/api/auth/approle/\#list-roles "Direct link to List roles")

This endpoint returns a list the existing AppRoles in the method.

| Method | Path |
| --- | --- |
| `LIST` | `/auth/approle/role` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters "Direct link to Parameters")

- `after``(string: "")` \- Optional entry to begin listing after for
pagination; not required to exist.

- `limit``(int: 0)` \- Optional number of entries to return; defaults
to all entries.


### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request LIST \

    http://127.0.0.1:8200/v1/auth/approle/role
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "keys": ["dev", "prod", "test"]

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Create/Update AppRole [​](https://openbao.org/docs/api/auth/approle/\#createupdate-approle "Direct link to Create/Update AppRole")

Creates a new AppRole or updates an existing AppRole. This endpoint
supports both `create` and `update` capabilities. There can be one or more
constraints enabled on the role. It is required to have at least one of them
enabled while creating or updating a role.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-1 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes, accepted characters
include a-Z, 0-9, space, hyphen, underscore and periods.
- `bind_secret_id``(bool: true)` \- Require `secret_id` to be presented when
logging in using this AppRole.
- `secret_id_bound_cidrs``(array: [])` \- Comma-separated string or list of CIDR
blocks; if set, specifies blocks of IP addresses which can perform the login
operation.
- `secret_id_num_uses``(integer: 0)` \- Number of times any particular SecretID
can be used to fetch a token from this AppRole, after which the SecretID by default
will expire. A value of zero will allow unlimited uses.
However, this option may be overridden by the request's 'num\_uses' field when generating a SecretID.
- `secret_id_ttl``(string: "")` \- Duration in either an integer number of
seconds (`3600`) or an integer time unit (`60m`) after which by default any SecretID
expires. A value of zero will allow the SecretID to not expire.
However, this option may be overridden by the request's 'ttl' field when generating a SecretID.
- `local_secret_ids``(bool: false)` \- If set, the secret IDs generated
using this role will be cluster local. This can only be set during role
creation and once set, it can't be reset later.

- `token_ttl``(integer: 0 or string: "")` \- The incremental lifetime for
generated tokens. This current value of this will be referenced at renewal
time.
- `token_max_ttl``(integer: 0 or string: "")` \- The maximum lifetime for
generated tokens. This current value of this will be referenced at renewal
time.
- `token_policies``(array: [] or comma-delimited string: "")` \- List of
token policies to encode onto generated tokens. Depending on the auth method, this
list may be supplemented by user/group/other values.
- `policies``(array: [] or comma-delimited string: "")` \- DEPRECATED: Please
use the `token_policies` parameter instead. List of token policies to encode
onto generated tokens. Depending on the auth method, this list may be
supplemented by user/group/other values.

- `token_bound_cidrs``(array: [] or comma-delimited string: "")` \- List of
CIDR blocks; if set, specifies blocks of IP addresses which can authenticate
successfully, and ties the resulting token to these blocks as well.
- `token_strictly_bind_ip``(bool: false)` \- If set, the token will be
restricted to the source IP address making the initial login request. This
conflicts with `token_bound_cidrs`.
- `token_explicit_max_ttl``(integer: 0 or string: "")` \- If set, will encode
an [explicit max\\
TTL](https://openbao.org/docs/concepts/tokens/#token-time-to-live-periodic-tokens-and-explicit-max-ttls)
onto the token. This is a hard cap even if `token_ttl` and `token_max_ttl`
would otherwise allow a renewal.
- `token_no_default_policy``(bool: false)` \- If set, the `default` policy will
not be set on generated tokens; otherwise it will be added to the policies set
in `token_policies`.
- `token_num_uses``(integer: 0)` \- The maximum number of times a generated
token may be used (within its lifetime); 0 means unlimited.
If you require the token to have the ability to create child tokens,
you will need to set this value to 0.
- `token_period``(integer: 0 or string: "")` \- The maximum allowed [period](https://openbao.org/docs/concepts/tokens/#token-time-to-live-periodic-tokens-and-explicit-max-ttls) value when a periodic token is requested from this role.
- `token_type``(string: "")` \- The type of token that should be generated. Can
be `service`, `batch`, or `default` to use the mount's tuned default (which
unless changed will be `service` tokens). For token store roles, there are two
additional possibilities: `default-service` and `default-batch` which specify
the type to return unless the client requests a different type at generation
time.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload "Direct link to Sample payload")

```json
{

  "token_ttl": "10m",

  "token_max_ttl": "15m",

  "token_policies": ["default"],

  "period": 0,

  "bind_secret_id": true

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-1 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1
```

## Read AppRole [​](https://openbao.org/docs/api/auth/approle/\#read-approle "Direct link to Read AppRole")

Reads the properties of an existing AppRole.

| Method | Path |
| --- | --- |
| `GET` | `/auth/approle/role/:role_name` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-2 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-2 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    http://127.0.0.1:8200/v1/auth/approle/role/application1
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-1 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "token_ttl": 1200,

    "token_max_ttl": 1800,

    "secret_id_ttl": 600,

    "secret_id_num_uses": 40,

    "token_policies": ["default"],

    "period": 0,

    "bind_secret_id": true,

    "secret_id_bound_cidrs": []

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Delete AppRole [​](https://openbao.org/docs/api/auth/approle/\#delete-approle "Direct link to Delete AppRole")

Deletes an existing AppRole from the method.

| Method | Path |
| --- | --- |
| `DELETE` | `/auth/approle/role/:role_name` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-3 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-3 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request DELETE \

    http://127.0.0.1:8200/v1/auth/approle/role/application1
```

## Read AppRole role ID [​](https://openbao.org/docs/api/auth/approle/\#read-approle-role-id "Direct link to Read AppRole role ID")

Reads the RoleID of an existing AppRole.

| Method | Path |
| --- | --- |
| `GET` | `/auth/approle/role/:role_name/role-id` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-4 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-4 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/role-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-2 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "role_id": "e5a7b66e-5d08-da9c-7075-71984634b882"

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Update AppRole role ID [​](https://openbao.org/docs/api/auth/approle/\#update-approle-role-id "Direct link to Update AppRole role ID")

Updates the RoleID of an existing AppRole to a custom value.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/role-id` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-5 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `role_id``(string: <required>)` \- Value to be set as RoleID.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-1 "Direct link to Sample payload")

```json
{

  "role_id": "custom-role-id"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-5 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/role-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-3 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "role_id": "e5a7b66e-5d08-da9c-7075-71984634b882"

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Generate new secret ID [​](https://openbao.org/docs/api/auth/approle/\#generate-new-secret-id "Direct link to Generate new secret ID")

Generates and issues a new SecretID on an existing AppRole. Similar to
tokens, the response will also contain a `secret_id_accessor` value which can
be used to read the properties of the SecretID without divulging the SecretID
itself, and also to delete the SecretID from the AppRole.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/secret-id` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-6 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `metadata``(string: "")` \- Metadata to be tied to the SecretID. This should be
a JSON-formatted string containing the metadata in key-value pairs. This
metadata will be set on tokens issued with this SecretID, and is logged in
audit logs _in plaintext_.
- `cidr_list``(array: [])` \- Comma separated string or list of CIDR blocks
enforcing secret IDs to be used from specific set of IP addresses. If
`secret_id_bound_cidrs` is set on the role, then the list of CIDR blocks listed
here should be a subset of the CIDR blocks listed on the role.
- `token_bound_cidrs``(array: [])` \- Comma-separated string or list of CIDR
blocks; if set, specifies blocks of IP addresses which can use the auth tokens
generated by this SecretID. Overrides any role-set value but must be a subset.
- `num_uses``(integer: 0)` \- Number of times this SecretID can be used, after which
the SecretID expires. A value of zero will allow unlimited uses.
Overrides secret\_id\_num\_uses role option when supplied.
May not be higher than role's secret\_id\_num\_uses.
- `ttl``(string: "")` \- Duration in seconds (`3600`) or an integer time unit (`60m`)
after which this SecretID expires. A value of zero will allow the SecretID to not expire.
Overrides secret\_id\_ttl role option when supplied.
May not be longer than role's secret\_id\_ttl.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-2 "Direct link to Sample payload")

```json
{

  "metadata": "{ \"tag1\": \"production\" }",

  "ttl": 600,

  "num_uses": 50

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-6 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-4 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "secret_id_accessor": "84896a0c-1347-aa90-a4f6-aca8b7558780",

    "secret_id": "841771dc-11c9-bbc7-bcac-6a3945a69cd9",

    "secret_id_ttl": 600,

    "secret_id_num_uses": 50

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## List secret ID accessors [​](https://openbao.org/docs/api/auth/approle/\#list-secret-id-accessors "Direct link to List secret ID accessors")

Lists the accessors of all the SecretIDs issued against the AppRole.
This includes the accessors for "custom" SecretIDs as well.

| Method | Path |
| --- | --- |
| `LIST` | `/auth/approle/role/:role_name/secret-id` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-7 "Direct link to Parameters")

- `after``(string: "")` \- Optional entry to begin listing after for
pagination; not required to exist.

- `limit``(int: 0)` \- Optional number of entries to return; defaults
to all entries.


### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-8 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-7 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request LIST \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-5 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "keys": [\
\
      "ce102d2a-8253-c437-bf9a-aceed4241491",\
\
      "a1c8dee4-b869-e68d-3520-2040c1a0849a",\
\
      "be83b7e2-044c-7244-07e1-47560ca1c787",\
\
      "84896a0c-1347-aa90-a4f6-aca8b7558780",\
\
      "239b1328-6523-15e7-403a-a48038cdc45a"\
\
    ]

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Read AppRole secret ID [​](https://openbao.org/docs/api/auth/approle/\#read-approle-secret-id "Direct link to Read AppRole secret ID")

Reads out the properties of a SecretID.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/secret-id/lookup` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-9 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `secret_id``(string: <required>)` \- Secret ID attached to the role.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-3 "Direct link to Sample payload")

```json
{

  "secret_id": "84896a0c-1347-aa90-a4f6-aca8b7558780"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-8 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id/lookup
```

### Sample Response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-6 "Direct link to Sample Response")

```json
{

  "request_id": "74752925-f309-6859-3d2d-0fcded95150e",

  "lease_id": "",

  "renewable": false,

  "lease_duration": 0,

  "data": {

    "cidr_list": [],

    "creation_time": "2023-02-10T18:17:27.089757383Z",

    "expiration_time": "0001-01-01T00:00:00Z",

    "last_updated_time": "2023-02-10T18:17:27.089757383Z",

    "metadata": {

      "tag1": "production"

    },

    "secret_id_accessor": "2be760a4-86bb-2fa9-1637-1b7fa9ba2896",

    "secret_id_num_uses": 0,

    "secret_id_ttl": 0,

    "token_bound_cidrs": []

  },

  "wrap_info": null,

  "warnings": null,

  "auth": null

}
```

## Destroy AppRole Secret ID [​](https://openbao.org/docs/api/auth/approle/\#destroy-approle-secret-id "Direct link to Destroy AppRole Secret ID")

Destroy an AppRole secret ID.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/secret-id/destroy` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-10 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `secret_id``(string: <required>)` \- Secret ID attached to the role.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-4 "Direct link to Sample payload")

```json
{

  "secret_id": "84896a0c-1347-aa90-a4f6-aca8b7558780"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-9 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id/destroy
```

## Read AppRole secret ID accessor [​](https://openbao.org/docs/api/auth/approle/\#read-approle-secret-id-accessor "Direct link to Read AppRole secret ID accessor")

Reads out the properties of a SecretID.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/secret-id-accessor/lookup` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-11 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `secret_id_accessor``(string: <required>)` \- Secret ID accessor attached to the role.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-5 "Direct link to Sample payload")

```json
{

  "secret_id_accessor": "84896a0c-1347-aa90-a4f6-aca8b7558780"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-10 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id-accessor/lookup
```

### Sample Response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-7 "Direct link to Sample Response")

```json
{

  "request_id": "72836cd1-139c-fe66-1402-8bb5ca4044b8",

  "lease_id": "",

  "renewable": false,

  "lease_duration": 0,

  "data": {

    "cidr_list": [],

    "creation_time": "2023-02-10T18:17:27.089757383Z",

    "expiration_time": "0001-01-01T00:00:00Z",

    "last_updated_time": "2023-02-10T18:17:27.089757383Z",

    "metadata": {

      "tag1": "production"

    },

    "secret_id_accessor": "2be760a4-86bb-2fa9-1637-1b7fa9ba2896",

    "secret_id_num_uses": 0,

    "secret_id_ttl": 0,

    "token_bound_cidrs": []

  },

  "wrap_info": null,

  "warnings": null,

  "auth": null

}
```

## Destroy AppRole Secret ID Accessor [​](https://openbao.org/docs/api/auth/approle/\#destroy-approle-secret-id-accessor "Direct link to Destroy AppRole Secret ID Accessor")

Destroy an AppRole secret ID by its accessor.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/secret-id-accessor/destroy` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-12 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `secret_id_accessor``(string: <required>)` \- Secret ID accessor attached to the role.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-6 "Direct link to Sample payload")

```json
{

  "secret_id_accessor": "84896a0c-1347-aa90-a4f6-aca8b7558780"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-11 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/secret-id-accessor/destroy
```

## Create custom AppRole secret ID [​](https://openbao.org/docs/api/auth/approle/\#create-custom-approle-secret-id "Direct link to Create custom AppRole secret ID")

Assigns a "custom" SecretID against an existing AppRole. This is used in the
"Push" model of operation.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/role/:role_name/custom-secret-id` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-13 "Direct link to Parameters")

- `role_name``(string: <required>)` \- Name of the AppRole. Must be less than 4096 bytes.
- `secret_id``(string: <required>)` \- SecretID to be attached to the Role.
- `metadata``(string: "")` \- Metadata to be tied to the SecretID. This should be
a JSON-formatted string containing the metadata in key-value pairs. This
metadata will be set on tokens issued with this SecretID, and is logged in
audit logs _in plaintext_.
- `cidr_list``(array: [])` \- Comma separated string or list of CIDR blocks
enforcing secret IDs to be used from specific set of IP addresses. If
`secret_id_bound_cidrs` is set on the role, then the list of CIDR blocks listed
here should be a subset of the CIDR blocks listed on the role.
- `token_bound_cidrs``(array: [])` \- Comma-separated string or list of CIDR
blocks; if set, specifies blocks of IP addresses which can use the auth tokens
generated by this SecretID. Overrides any role-set value but must be a subset.
- `num_uses``(integer: 0)` \- Number of times this SecretID can be used, after which
the SecretID expires. A value of zero will allow unlimited uses.
Overrides secret\_id\_num\_uses role option when supplied.
May not be higher than role's secret\_id\_num\_uses.
- `ttl``(string: "")` \- Duration in seconds (`3600`) or an integer time unit (`60m`)
after which this SecretID expires. A value of zero will allow the SecretID to not expire.
Overrides secret\_id\_ttl role option when supplied.
May not be longer than role's secret\_id\_ttl.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-7 "Direct link to Sample payload")

```json
{

  "secret_id": "testsecretid",

  "ttl": 600,

  "num_uses": 50

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-12 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/role/application1/custom-secret-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-8 "Direct link to Sample response")

```json
{

  "auth": null,

  "warnings": null,

  "wrap_info": null,

  "data": {

    "secret_id": "testsecretid",

    "secret_id_accessor": "84896a0c-1347-aa90-a4f6-aca8b7558780",

    "secret_id_ttl": 600,

    "secret_id_num_uses": 50

  },

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Login with AppRole [​](https://openbao.org/docs/api/auth/approle/\#login-with-approle "Direct link to Login with AppRole")

Issues an OpenBao token based on the presented credentials. `role_id` is always
required; if `bind_secret_id` is enabled (the default) on the AppRole,
`secret_id` is required too. Any other bound authentication values on the
AppRole (such as client IP CIDR) are also evaluated.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/login` |

### Parameters [​](https://openbao.org/docs/api/auth/approle/\#parameters-14 "Direct link to Parameters")

- `role_id``(string: <required>)` \- RoleID of the AppRole.
- `secret_id``(string: <required>)` \- SecretID belonging to AppRole.

### Sample payload [​](https://openbao.org/docs/api/auth/approle/\#sample-payload-8 "Direct link to Sample payload")

```json
{

  "role_id": "59d6d1ca-47bb-4e7e-a40b-8be3bc5a0ba8",

  "secret_id": "84896a0c-1347-aa90-a4f6-aca8b7558780"

}
```

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-13 "Direct link to Sample request")

```shell-session
$ curl \

    --request POST \

    --data @payload.json \

    http://127.0.0.1:8200/v1/auth/approle/login
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-9 "Direct link to Sample response")

```json
{

  "auth": {

    "renewable": true,

    "lease_duration": 1200,

    "metadata": null,

    "token_policies": ["default"],

    "accessor": "fd6c9a00-d2dc-3b11-0be5-af7ae0e1d374",

    "client_token": "5b1a0318-679c-9c45-e5c6-d1b9a9035d49"

  },

  "warnings": null,

  "wrap_info": null,

  "data": null,

  "lease_duration": 0,

  "renewable": false,

  "lease_id": ""

}
```

## Read, update, or delete AppRole properties [​](https://openbao.org/docs/api/auth/approle/\#read-update-or-delete-approle-properties "Direct link to Read, update, or delete AppRole properties")

Updates the respective property in the existing AppRole. All of these
parameters of the AppRole can be updated using the `/auth/approle/role/:role_name`
endpoint directly. The endpoints for each field is provided separately
to be able to delegate specific endpoints using OpenBao's ACL system.

| Method | Path | Code |
| --- | --- | --- |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/policies` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/secret-id-num-uses` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/secret-id-ttl` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/token-ttl` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/token-max-ttl` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/bind-secret-id` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/secret-id-bound-cidrs` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/token-bound-cidrs` | `200/204` |
| `GET/POST/DELETE` | `/auth/approle/role/:role_name/period` | `200/204` |

Refer to `/auth/approle/role/:role_name` endpoint.

## Tidy tokens [​](https://openbao.org/docs/api/auth/approle/\#tidy-tokens "Direct link to Tidy tokens")

Performs some maintenance tasks to clean up invalid entries that may remain
in the token store. Generally, running this is not needed unless upgrade
notes or support personnel suggest it. This may perform a lot of I/O to the
storage method so should be used sparingly.

| Method | Path |
| --- | --- |
| `POST` | `/auth/approle/tidy/secret-id` |

### Sample request [​](https://openbao.org/docs/api/auth/approle/\#sample-request-14 "Direct link to Sample request")

```shell-session
$ curl \

    --header "X-Vault-Token: ..." \

    --request POST \

    http://127.0.0.1:8200/v1/auth/approle/tidy/secret-id
```

### Sample response [​](https://openbao.org/docs/api/auth/approle/\#sample-response-10 "Direct link to Sample response")

```json
{

  "request_id": "b20b56e3-4699-5b19-cc6b-e74f7b787bbf",

  "lease_id": "",

  "renewable": false,

  "lease_duration": 0,

  "data": null,

  "wrap_info": null,

  "warnings": [\
\
    "Tidy operation successfully started. Any information from the operation will be printed to OpenBao's server logs."\
\
  ],

  "auth": null

}
```

- [List roles](https://openbao.org/docs/api/auth/approle/#list-roles)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response)
- [Create/Update AppRole](https://openbao.org/docs/api/auth/approle/#createupdate-approle)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-1)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-1)
- [Read AppRole](https://openbao.org/docs/api/auth/approle/#read-approle)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-2)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-2)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-1)
- [Delete AppRole](https://openbao.org/docs/api/auth/approle/#delete-approle)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-3)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-3)
- [Read AppRole role ID](https://openbao.org/docs/api/auth/approle/#read-approle-role-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-4)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-4)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-2)
- [Update AppRole role ID](https://openbao.org/docs/api/auth/approle/#update-approle-role-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-5)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-1)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-5)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-3)
- [Generate new secret ID](https://openbao.org/docs/api/auth/approle/#generate-new-secret-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-6)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-2)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-6)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-4)
- [List secret ID accessors](https://openbao.org/docs/api/auth/approle/#list-secret-id-accessors)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-7)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-8)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-7)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-5)
- [Read AppRole secret ID](https://openbao.org/docs/api/auth/approle/#read-approle-secret-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-9)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-3)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-8)
  - [Sample Response](https://openbao.org/docs/api/auth/approle/#sample-response-6)
- [Destroy AppRole Secret ID](https://openbao.org/docs/api/auth/approle/#destroy-approle-secret-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-10)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-4)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-9)
- [Read AppRole secret ID accessor](https://openbao.org/docs/api/auth/approle/#read-approle-secret-id-accessor)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-11)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-5)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-10)
  - [Sample Response](https://openbao.org/docs/api/auth/approle/#sample-response-7)
- [Destroy AppRole Secret ID Accessor](https://openbao.org/docs/api/auth/approle/#destroy-approle-secret-id-accessor)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-12)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-6)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-11)
- [Create custom AppRole secret ID](https://openbao.org/docs/api/auth/approle/#create-custom-approle-secret-id)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-13)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-7)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-12)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-8)
- [Login with AppRole](https://openbao.org/docs/api/auth/approle/#login-with-approle)
  - [Parameters](https://openbao.org/docs/api/auth/approle/#parameters-14)
  - [Sample payload](https://openbao.org/docs/api/auth/approle/#sample-payload-8)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-13)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-9)
- [Read, update, or delete AppRole properties](https://openbao.org/docs/api/auth/approle/#read-update-or-delete-approle-properties)
- [Tidy tokens](https://openbao.org/docs/api/auth/approle/#tidy-tokens)
  - [Sample request](https://openbao.org/docs/api/auth/approle/#sample-request-14)
  - [Sample response](https://openbao.org/docs/api/auth/approle/#sample-response-10)
