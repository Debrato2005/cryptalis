import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).parent
source = root / 'source'
python = '/home/debrato/Projects/cryptalis/.venv/bin/python'
env = dict(os.environ, PYTHONPATH=str(source / 'src'))
cases = json.loads((root / 'mutations.json').read_text())
for case in cases:
    if case['name'] == 'malformed plan refusal':
        case['tests'] = ['tests/test_project.py::test_unsafe_state_and_mismatched_inputs_refuse']
    if case['name'] == 'invalid session tenant first':
        case['tests'] = ['tests/test_project.py::test_unknown_tenant_refuses_before_any_shared_key_lookup']


def run(label, tests):
    label = 'round2-' + label
    receipt = root / (label + '.json')
    command = [python, 'scripts/test_postgres.py', '--receipt', str(receipt),
               '--scope', 'Final pruned-suite audit: ' + label, '--', *tests,
               '-q', '-p', 'no:cacheprovider', '--tb=short']
    started = time.monotonic()
    with (root / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=source, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=300)
    if not receipt.exists():
        raise RuntimeError(label + ': no receipt; stop and inspect log')
    data = json.loads(receipt.read_text())
    if result.returncode not in (0, 1):
        raise RuntimeError(label + ': wrapper failure; stop and inspect log')
    return {'exit_code': result.returncode, 'seconds': round(time.monotonic()-started, 2),
            'receipt': receipt.name, 'counts': data['pytest_report_counts'],
            'modules': data['modules'], 'source_stability': data['source_stability'],
            'runtime_binding_stability': data['runtime_binding_stability']}


selected = sorted(set(test for case in cases for test in case['tests']) |
                  {'tests/test_migration_audit.py'})
baseline = run('final-baseline', selected)
assert baseline['exit_code'] == 0, baseline
print('Healthy baseline:', baseline['counts'], flush=True)
results = []
for index, case in enumerate(cases, 1):
    target = source / case['path']
    original = target.read_bytes()
    text = original.decode()
    assert text.count(case['old']) == 1
    modified = text.replace(case['old'], case['new']).encode()
    try:
        target.write_bytes(modified)
        result = run(f'final-mutant-{index:02}', case['tests'])
    finally:
        target.write_bytes(original)
    result.update(case, original_sha256=hashlib.sha256(original).hexdigest(),
                  mutated_sha256=hashlib.sha256(modified).hexdigest())
    results.append(result)
    (root / 'final-results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(case['name'], result['exit_code'], result['counts'], flush=True)
final = run('final-healthy-project', ['tests/test_project.py'])
assert final['exit_code'] == 0, final
print('Full Project regression:', final['counts'], flush=True)
