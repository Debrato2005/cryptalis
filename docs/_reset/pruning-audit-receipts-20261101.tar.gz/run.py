import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
SOURCE = ROOT / 'source'
PYTHON = '/home/debrato/Projects/cryptalis/.venv/bin/python'
env = dict(os.environ, PYTHONPATH=str(SOURCE / 'src'))
cases = json.loads((ROOT / 'mutations.json').read_text())
results = []


def run(label, tests):
    receipt = ROOT / (label + '.json')
    command = [PYTHON, 'scripts/test_postgres.py', '--receipt', str(receipt),
               '--scope', 'Pruned-suite mutation audit: ' + label, '--',
               *tests, '-q', '-p', 'no:cacheprovider', '--tb=short']
    started = time.monotonic()
    with (ROOT / (label + '.log')).open('w') as log:
        completed = subprocess.run(command, cwd=SOURCE, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, timeout=300)
    output = (ROOT / (label + '.log')).read_text()
    data = json.loads(receipt.read_text()) if receipt.exists() else None
    if completed.returncode not in (0, 1) or data is None:
        raise RuntimeError(label + ' stopped: wrapper/collection failure; inspect private log')
    return {'exit_code': completed.returncode, 'seconds': round(time.monotonic()-started, 2),
            'receipt': receipt.name, 'failures': [line for line in output.splitlines()
                 if line.startswith(('FAILED ', 'ERROR '))],
            'counts': data.get('pytest_report_counts', {})}


extra = run('baseline-authority', [
    'tests/test_application_config.py::test_shared_lifecycle_never_infers_host_authority[plaintext]',
    'tests/test_application_config.py::test_shared_lifecycle_never_infers_host_authority[removal]'])
assert extra['exit_code'] == 0, extra
for index, case in enumerate(cases, 1):
    target = SOURCE / case['path']
    original = target.read_bytes()
    text = original.decode()
    assert text.count(case['old']) == 1, case['name']
    modified = text.replace(case['old'], case['new']).encode()
    try:
        target.write_bytes(modified)
        result = run(f'mutant-{index:02}', case['tests'])
    finally:
        target.write_bytes(original)
    result.update(name=case['name'], path=case['path'], tests=case['tests'],
        original_sha256=hashlib.sha256(original).hexdigest(),
        mutated_sha256=hashlib.sha256(modified).hexdigest())
    results.append(result)
    (ROOT / 'initial-results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(case['name'], result['exit_code'], result['failures'], flush=True)
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE) == b''
print('All ten attempts recorded; isolated source restored.', flush=True)
