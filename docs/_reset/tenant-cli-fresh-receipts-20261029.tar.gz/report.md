# Restored tenant provisioning through the public CLI — 2026-10-29

IMPLEMENTED and VERIFIED only in disposable local PostgreSQL16/public fixture cells. All seven production gates remain UNKNOWN. No production custody, authorization or pause-budget qualification is claimed.

## Exact change

Worktree `/workspace/.cryptalis-cloud/tenant-cli-fresh`, branch `wip/tenant-cli-fresh-20261028`, base `1a3d93402e376ff67b7899a30a77b748b0035b48`. Exactly two test profile files changed; no CLI/core/main/docs changes, commits, environments or package changes made.

The existing `provision_account`/`complete_lifecycle` functions accept an optional publication callback. The default source v15 journey retains the existing Python lifecycle path. Original signup, JWT authentication, active administrator authorization and exact typed account UUID/key approval still precede any callback; unapproved Item creation still returns409 before scoped key selection. Both paths retain all existing old-frame/schema/lock/policy identity, stale-host refusal, first HTTP Item/edit/read and latest native exit checks.

The restored profile supplies a fixture host adapter that calls the public `cli.main` parser/runner for tenant provision plan/apply/activate. This is the public command entrypoint in-process with trusted MODULE:FACTORY contexts, not a shell subprocess. It uses the installed CLI implementation in the installed cell. Host-approved UUID and Keyring stay in the authenticated host closure; no command flag, database row or frame chooses keys. The callback creates no alternative transition implementation. Existing O(N) frame verification and the global writer pause remain unchanged; this does not qualify scalable online SaaS provisioning.

Source artifact and separately versioned host ACTIVE/PREPARED/ACTIVATING/successor-ACTIVE pins are private, fsynced retained files. The fixture host explicitly publishes each version independently of the database and CLI. The CLI itself durably retains the exact proposal/successor using its existing artifact machinery. The factory verifies the exact successor already exists before returning its apply context. Each returned context supplies a fresh owned Engine, and all four returned engines are disposed. A malformed v16 artifact refuses before factory invocation; PREPARED activation refuses with tenant_provision_executor_required before key lookup. Only the independently published actual ACTIVATING pin activates the saved v16 successor. Source ACTIVE pin bytes stay unchanged.

After activation the existing original HTTP/JWT/admin/cascade workload, first new tenant Item and latest NULL/Unicode edits, current-value reversal/removal, and import-denied restarted native child remain the acceptance oracle. The child reads the actual retained11Items/10owners and asserts no Cryptalis import. Original26application files remain byte-identical.

## Executable evidence

Preserved RED: `/tmp/cryptalis-tenant-cli-fresh-red-20261028`: source1pass, restored1failed when the preexisting Python-only restore did not report CLI publication. Initial implementation run `/tmp/cryptalis-tenant-cli-fresh-source-20261029`: source1pass, restored1failed because the new test expected a later publication-refusal code. Investigation confirmed the existing executor refuses PREPARED earlier with tenant_provision_executor_required before keys. Only that expected assertion was corrected; product behavior was unchanged. Both failed receipt sets remain.

Final source: `/tmp/cryptalis-tenant-cli-fresh-source2-20261029`: source1pass and restored1pass, all source hashes/runtime44modules stable, three authenticated roles freshly probed in each phase. Source cluster stops successfully before the distinct restored cluster starts. This source cell deliberately binds the isolated1a3 package.

Final installed: `/tmp/cryptalis-tenant-cli-fresh-installed-20261029`: source1pass and restored1pass, empty PYTHONPATH and --installed-wheel guard, all source hashes/runtime45modules stable, three-role probes in each phase. Installed interpreter `/workspace/.cryptalis-cloud/integrated-http-20261029/bin/python`; wheel `/tmp/cryptalis-integrated-release-private-20261029/artifacts/cryptalis-0.1.0-py3-none-any.whl`, SHA256 `c1ac937ace1e1f079a854d4bdfa0f8db96ab1edeea3a71c4536cc7fa5517e50f`. The same candidate fixtures exercise current integrated core through the inspected wheel; no claim of matching isolated source/package hashes is made. Both phases have one existing Starlette/httpx deprecation warning, no skips or failures.

Each successful restored application.json records the v16 CLI phases PREPARED/PENDING/ACTIVE, negative ordering controls, proposal/successor digests, all8retained artifact hashes and4ownedEngine disposals. Each source/restored application records original26file SHA256s, no source edits, all7gatesUNKNOWN, and import-denied retained Item HTTP proof. Copies of all8exact private CLI/host artifacts are retained alongside each successful restored report in `restored/tenant-provision-cli`, verified against the recorded SHA256 map before copying. Public fixture reconstruction and local durability do not establish live independent custody or production publication authority.

Structured summaries: `/tmp/cryptalis-tenant-cli-fresh-evidence-20261029.json` (full runtime bindings and application boundary). Independent build_review accepted both profile diffs and the corrected refusal assertion; no remaining actionable findings. No unrelated state-matrix expansion or full suite rerun was performed for these test-only additions.

## Owned-file handoff

- `tests/profile_sqlmodel_http_tenant_application.py`: `06345ce03511e16078f896195ad6bf74c29cf5c46fadc20f534cc66ca58e610b`
- `tests/profile_sqlmodel_http_tenant_restore.py`: `50e7a6847e6b47836aef224d069ae7e5a2d5642dbf25120d4a80641985c3532f`

`git diff --check` passes. Root can integrate exactly these2files without copying old core/harness fixtures. Parent owns integration, canonical records, commit/push and remote verification.
