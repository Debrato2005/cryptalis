"""Real strict-TLS provider boundary, using an installed inspected wheel; no PostgreSQL."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
from uuid import uuid4

import hvac
from cryptalis.crypto.keys import KeyContext, create_root
from cryptalis.crypto.openbao import OpenBaoTransitKeyProvider

os.umask(0o077)
source = Path('/workspace/cryptalis-production')
work = Path('/workspace/scratch/openbao-strict-tls-20261101')
service_dir = work / 'private-service'
service_dir.mkdir(mode=0o700)
helper = source / 'scripts/openbao_qualification.py'
spec = importlib.util.spec_from_file_location('fixed_openbao_service', helper)
service = importlib.util.module_from_spec(spec)
spec.loader.exec_module(service)
source_hash = hashlib.sha256(helper.read_bytes()).hexdigest()
wheel = Path('/workspace/scratch/cryptalis-package-20261101/artifacts/cryptalis-0.1.0a1-py3-none-any.whl')
red = Path('/workspace/scratch/smolink-preview-private/openbao/tls-repair-receipt.json')
red_content = json.loads(red.read_text())
container = 'cryptalis-bao-' + uuid4().hex
report = dict(format='cryptalis.openbao-strict-tls-boundary/v1', status='INCOMPLETE',
    source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
    helper_path='scripts/openbao_qualification.py', helper_sha256=source_hash,
    python=sys.version.split()[0], openssl=ssl.OPENSSL_VERSION, image=service.IMAGE,
    wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
    red_evidence=dict(failure=red_content['prior_failure'], receipt_sha256=hashlib.sha256(red.read_bytes()).hexdigest(),
       retained='private original demo receipt and failed protect output; not replayed here'),
    controls={}, cleanup='NOT_STARTED', gate='UNKNOWN',
    scope='Fresh local TLS/Raft OpenBao provider boundary only; no PostgreSQL tests or runtime modifications')
created = False
primary = None
client = None
try:
    binding = subprocess.run([sys.executable,str(source/'scripts/test_postgres.py'),
        '--installed-wheel',str(wheel),'--runtime-binding-only'],cwd=source,capture_output=True,text=True)
    if binding.returncode:
        raise RuntimeError('InstalledWheelBindingFailed')
    report['runtime_binding'] = json.loads(binding.stdout)['runtime_binding']
    service.service_files(service_dir)
    endpoint = service.start_container(service_dir,container)
    created = True
    service.write_private(service_dir/'container-name',container.encode())
    tls = ssl.create_default_context(cafile=str(service_dir/'ca.pem'))
    report['tls_verify_flags'] = int(tls.verify_flags)
    if not tls.verify_flags & ssl.VERIFY_X509_STRICT:
        raise RuntimeError('StrictTLSUnavailable')
    with socket.create_connection(('127.0.0.1',int(endpoint.rsplit(':',1)[1])),timeout=10) as connection:
        with tls.wrap_socket(connection,server_hostname='127.0.0.1') as secured:
            report['controls']['strict_tls_handshake'] = 'PASS'
            report['tls_protocol'] = secured.version()
    client = hvac.Client(url=endpoint,token='',verify=str(service_dir/'ca.pem'),allow_redirects=False,timeout=10)
    if service.wait_available(client):
        raise RuntimeError('UnexpectedInitializedService')
    initialized = client.sys.initialize(secret_shares=1,secret_threshold=1)
    service.write_private(service_dir/'initialization.json',json.dumps(initialized).encode())
    client.sys.submit_unseal_key(initialized['keys'][0])
    service.wait_active(client)
    client.token = initialized['root_token']
    report['service_version'] = client.sys.read_health_status(method='GET')['version']
    client.sys.enable_secrets_engine('transit',path='transit')
    key='strict-tls-control'
    client.write('transit/keys/'+key,type='aes256-gcm96',derived=False,exportable=False,allow_plaintext_backup=False)
    policy='\n'.join(f'path "transit/{operation}/{key}" {{ capabilities = ["{capability}"] }}'
        for operation,capability in [('keys','read'),('encrypt','update'),('decrypt','update')])
    client.sys.create_or_update_policy(key,policy)
    token=client.auth.token.create(policies=[key],no_default_policy=True,ttl='1h')['auth']['client_token']
    service.write_private(service_dir/'runtime-token',token.encode())
    provider = OpenBaoTransitKeyProvider(endpoint=endpoint,ca_cert=str(service_dir/'ca.pem'),token=lambda: token,
        provider_id=uuid4(),key_name=key,key_version=1,timeout=10)
    context=KeyContext(uuid4(),uuid4(),'payload',uuid4(),1)
    wrapper=create_root(provider,context)
    assert len(provider.unwrap(wrapper,context)) == 32
    report['controls']['installed_public_create_root_unwrap']='PASS'
    native=hvac.Client(url=endpoint,token=token,verify=str(service_dir/'ca.pem'),allow_redirects=False,timeout=10)
    try:
        encoded=lambda value: base64.b64encode(value).decode('ascii')
        ciphertext=native.write('transit/encrypt/'+key,plaintext=encoded(b'PUBLIC TLS CONTROL'),
            associated_data=encoded(b'public-aad'),key_version=1)['data']['ciphertext']
        try:
            native.write('transit/decrypt/'+key,ciphertext=ciphertext,associated_data=encoded(b'wrong-public-aad'))
        except hvac.exceptions.InvalidRequest:
            report['controls']['native_wrong_aad']='REFUSED'
        else:
            raise RuntimeError('WrongAADAccepted')
        try:
            native.write('transit/keys/'+key+'/rotate')
        except hvac.exceptions.Forbidden:
            report['controls']['native_key_administration']='DENIED'
        else:
            raise RuntimeError('KeyAdministrationAccepted')
    finally:
        native.session.close()
    if hashlib.sha256(helper.read_bytes()).hexdigest() != source_hash:
        raise RuntimeError('HelperChangedDuringRun')
    report['controls']['helper_unchanged']='PASS'
    report['status']='PASS'
except BaseException as error:
    primary=error
    report.update(status='FAIL',failure_type=type(error).__name__)
finally:
    if client is not None:
        client.session.close()
    if created:
        try:
            service.retire_container(service_dir,container)
            report['cleanup']='PASS; stopped container removed after private log retention; custody files retained'
        except BaseException as error:
            report.update(status='FAIL',cleanup='FAIL',cleanup_failure_type=type(error).__name__)
            if primary is None:
                primary=error
    report['helper_final_sha256']=hashlib.sha256(helper.read_bytes()).hexdigest()
    (work/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('status','python','controls','cleanup','helper_sha256')}))
if primary is not None:
    raise SystemExit(1)
